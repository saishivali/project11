# C_11_indented_code
Teacher activity 2 solution( indented code)
